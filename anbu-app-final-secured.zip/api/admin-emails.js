const { verifyGoogleToken } = require("./_lib/verifyGoogleToken");
const { readAllowedEmails, writeAllowedEmails } = require("./_lib/store");

const ADMIN_EMAIL = "meleriskyyoga262@gmail.com";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_BODY = 2048;

function bearerToken(req) {
  const value = req.headers && (req.headers.authorization || req.headers.Authorization);
  if (!value || typeof value !== "string") return "";
  const m = value.match(/^Bearer\s+(.+)$/i);
  return m ? m[1].trim() : "";
}

async function requireAdmin(req, res) {
  const idToken = bearerToken(req);
  const email = await verifyGoogleToken(idToken);
  if (!email || email !== ADMIN_EMAIL) {
    res.status(403).json({ error: "admin only" });
    return null;
  }
  return email;
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (!["POST", "DELETE"].includes(req.method)) {
    res.setHeader("Allow", "POST, DELETE");
    res.status(405).json({ error: "method not allowed" });
    return;
  }

  const rawBody = JSON.stringify(req.body || {});
  if (rawBody.length > MAX_BODY) {
    res.status(413).json({ error: "request too large" });
    return;
  }

  const admin = await requireAdmin(req, res);
  if (!admin) return;

  if (req.method === "POST") {
    const action = String((req.body && req.body.action) || "").toLowerCase();
    const emails = await readAllowedEmails();

    if (action === "list") {
      res.status(200).json({ emails, adminEmail: ADMIN_EMAIL });
      return;
    }

    if (action !== "add") {
      res.status(400).json({ error: "invalid action" });
      return;
    }

    const target = String((req.body && req.body.email) || "").trim().toLowerCase();
    if (!EMAIL_RE.test(target)) {
      res.status(400).json({ error: "invalid email" });
      return;
    }
    if (emails.length >= 50 && !emails.includes(target)) {
      res.status(400).json({ error: "email limit reached" });
      return;
    }
    if (!emails.includes(target)) emails.push(target);
    await writeAllowedEmails(emails);
    res.status(200).json({ emails });
    return;
  }

  const target = String((req.body && req.body.email) || "").trim().toLowerCase();
  if (!EMAIL_RE.test(target)) {
    res.status(400).json({ error: "invalid email" });
    return;
  }
  if (target === ADMIN_EMAIL) {
    res.status(400).json({ error: "cannot remove admin" });
    return;
  }
  const emails = (await readAllowedEmails()).filter((e) => e !== target);
  await writeAllowedEmails(emails);
  res.status(200).json({ emails });
};
