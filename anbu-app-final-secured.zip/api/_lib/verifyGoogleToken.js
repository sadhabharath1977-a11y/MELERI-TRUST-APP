const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "323362878068-gpr8osss81v1t2qv85ffedmca7dld54u.apps.googleusercontent.com";

// Google performs the cryptographic signature validation at tokeninfo. We additionally
// enforce our OAuth audience, issuer, verified email and a reasonable token size/timeout.
async function verifyGoogleToken(idToken) {
  if (!idToken || typeof idToken !== "string" || idToken.length > 8192) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(idToken), {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    if (!r.ok) return null;
    const data = await r.json();
    const issuer = String(data.iss || "");
    if (data.aud !== GOOGLE_CLIENT_ID) return null;
    if (issuer !== "accounts.google.com" && issuer !== "https://accounts.google.com") return null;
    if (!data.email || data.email_verified !== "true") return null;
    if (!data.exp || Number(data.exp) <= Math.floor(Date.now() / 1000)) return null;
    return String(data.email).trim().toLowerCase();
  } catch (e) {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

module.exports = { verifyGoogleToken, GOOGLE_CLIENT_ID };
