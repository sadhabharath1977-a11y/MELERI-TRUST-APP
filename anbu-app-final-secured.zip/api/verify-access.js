const { verifyGoogleToken } = require("./_lib/verifyGoogleToken");
const { readAllowedEmails } = require("./_lib/store");

const ADMIN_EMAIL = "meleriskyyoga262@gmail.com";

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    res.status(405).json({ error: "method not allowed" });
    return;
  }
  try {
    const { idToken } = req.body || {};
    const email = await verifyGoogleToken(idToken);
    if (!email) {
      res.status(401).json({ allowed: false });
      return;
    }
    const emails = await readAllowedEmails();
    const allowed = emails.includes(email);
    res.status(200).json({ allowed, isAdmin: allowed && email === ADMIN_EMAIL, email });
  } catch (e) {
    res.status(500).json({ error: "server error" });
  }
};
